module.exports = {
  '*.{js,ts}': 'npm run lint:js',
  '*.{yml}': 'npm run lint:yml',
};
