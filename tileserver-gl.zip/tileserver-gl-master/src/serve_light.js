/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unused-vars */
'use strict';

export const serve_rendered = {
  init: (options, repo) => {},
  add: (options, repo, params, id, publicUrl, dataResolver) => {},
  remove: (repo, id) => {},
};
